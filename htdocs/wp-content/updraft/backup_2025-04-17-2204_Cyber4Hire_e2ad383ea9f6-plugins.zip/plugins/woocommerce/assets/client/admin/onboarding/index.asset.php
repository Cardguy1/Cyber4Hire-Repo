<?php return array('dependencies' => array('react', 'wc-components', 'wc-experimental', 'wc-tracks', 'wp-components', 'wp-compose', 'wp-element', 'wp-i18n'), 'version' => '381402872c452444dcb0');
